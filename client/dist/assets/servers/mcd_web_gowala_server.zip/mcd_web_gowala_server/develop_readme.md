# NodeJS Backend

## Default NODEJS backend med Auth Sign in


## Generate New JWT Secret. (ikke dødnødvendigt vi kan bare benytte den samme)
```
node -r dotenv/config ./lib/db/mcd/misc/generateSecret.js
```

